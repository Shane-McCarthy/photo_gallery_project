<?php
/**
 * Created by PhpStorm.
 * User: Shane McCarthy
 * Date: 1/14/14
 * Time: 9:06 AM
 */

// for simplicity I have left all the code on one page.
// otherwise I would have included the functions in another page and autoloaded it.

if (isset($_POST['username'])){
    $username=trim($_POST['username']);
    $message_user = "Welcome {$username}<br /> ";
}else {
    $username = "";
    $message_user = "user name invalid entry<br /> ";
}
if (isset($_POST['postalcode'])){
    $postalcode=trim($_POST['postalcode']);
    $postalcode = strtoupper($postalcode);

    $message_postal = "your postal code is : {$postalcode}<br /> ";
}else {
    $postalcode = "";
    $message_postal = "postalcode invalid entry<br /> ";
}

    $pattern_postal = "^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$^";
    $pattern_name = "^[\s\S]{4,}^";

        function testRegex($pattern, $testString){
       // echo "<p>Testing string ".$testString." against pattern ".$pattern ."</p>";
        if(  preg_match($pattern, $testString) == 0  ){
            echo "<p>Your information at {$testString} is in an incorrect format.</p>";
            echo "<p>Please re-enter you information below.</p>";
        }else{
            echo "<p>Great success!</p>";
        }
        }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Quiz 3: Form</title>
    <style type="text/css"></style>
</head>
<body>
<?php echo $message_user." ".$message_postal;
    testRegex($pattern_postal,$postalcode);
    testRegex($pattern_name,$username);
?>
<h2>Quiz 3: HTML Form with regular expression processing script</h2>
<form method="post" action="quiz03.php" style="width:350px;">
    <fieldset>
        <legend>Please input a Username and Postal Code</legend>
        <input type="text" name="username" id="username" /> -
        <label for="username">Username</label>


        <input type="text" name="postalcode" id="postalcode" /> -
        <label for="postalcode">Postal Code</label>

        <br />
        <input type="submit" value="Submit" />
    </fieldset>
</form>

</body>
</html>